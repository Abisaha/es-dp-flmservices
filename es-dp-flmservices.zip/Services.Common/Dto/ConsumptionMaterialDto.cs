﻿using Services.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLM.Services.ApplicationCommon.Dto
{
    public class ConsumptionMaterialDto
    {
        public string Id { get; set; }
        public string MaterialNumber { get;  set; }
        public string MaterialDesc { get;  set; }
        public string UOM { get;  set; }
        public string BatchNumber { get;  set; }
        public string SerialNumber { get;  set; }
        public string SplitValuation { get;  set; }
        public string Plant { get;  set; }
        public string IssuingStorageLocation { get;  set; }
        public string ReceivingStorageLocation { get;  set; }
        public string SpecialStockIndicator { get;  set; }
        public List<ConsumptionDto> Consumptions { get;  set; }
        public decimal ReceivedQuantity { get;  set; }
        public ConsumptionMaterialDto(string id, string materialNumber, string materialDesc, string uom, string batchNumber, string serialNumber,
          string splitValuation, string plant, string issuingStorageLocation, string receivingStorageLocation, string specialStockIndicator, List<ConsumptionDto> consumptions, decimal receivedQuantity)
        {
            Id = id;
            MaterialNumber = materialNumber;
            MaterialDesc = materialDesc;
            UOM = uom;
            BatchNumber = batchNumber;
            SerialNumber = serialNumber;
            SplitValuation = splitValuation;
            Plant = plant;
            IssuingStorageLocation = issuingStorageLocation;
            ReceivingStorageLocation = receivingStorageLocation;
            SpecialStockIndicator = specialStockIndicator;
            Consumptions = consumptions;
            ReceivedQuantity = receivedQuantity;
        }

    }
}
