﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics.CodeAnalysis;
using Rhino.Mocks;
using Services.Common;
using FLM.Services.ShipmentService;
using Services.Common.Domain;
using FLM.Services.ShipmentService.Model;
using FLM.Services.ShipmentService.Repository.Interface;
using System;
using Services.Common.Logger;
using Services.Common.Exceptions;
using FLM.CommonAdapter;
using FDP.Services.SAPAdapter.ShipmentService;
using FLM.Services.ShipmentService.Model.Shipments;

namespace FLM.Services.Tests
{
    /// <summary>
    /// Test Class for shipmentService
    /// </summary>
    [ExcludeFromCodeCoverage]
    [TestClass]
    public class ShipmentServiceTest
    {
        #region Private Fields
        IAuditContext mockAuditContext;
        IDispatcher Mockdispatcher = null;
        IShipmentRepository mockShipmentRepository;
        ShipmentService.ShipmentService mockShipmentService;
        ICommonAdapter mockcommonAdapter;
        ISAPShipmentService mockSapShipmentService;
        IShipmentServiceClient mockShipmentServiceClient;
        List<GoodsIssue> mockShipments;
        GoodsIssue mockShipment;
        private readonly string shipmentId = "SH1000000001";
        #endregion
        [TestInitialize]
        public void TestIntialize()
        {
            //arrange 
            ServiceCall();
            //data
           // TestDataSetup();
        }
        private void SetMockRepository()
        {
            mockAuditContext = MockRepository.GenerateMock<IAuditContext>();
            mockShipmentRepository = MockRepository.GenerateMock<IShipmentRepository>();
            Mockdispatcher = MockRepository.GenerateMock<IDispatcher>();
            mockcommonAdapter = MockRepository.GenerateMock<ICommonAdapter>();
            mockSapShipmentService = MockRepository.GenerateMock<ISAPShipmentService>();
        }
        private void ServiceCall()
        {
            SetMockRepository();
            mockShipmentServiceClient = MockRepository.GenerateMock<IShipmentServiceClient>(null);
            mockShipmentService = MockRepository.GenerateMock<ShipmentService.ShipmentService>(mockShipmentRepository,
                                      mockAuditContext, Mockdispatcher, mockcommonAdapter, mockSapShipmentService, mockShipmentServiceClient); 
        }
        //private void TestDataSetup()
        //{
        //    GoodsIssue shipmentMaterials = new GoodsIssue(3, "SR.18.SCA.0000001", "MR.18.NAL.0000001", "TR.18.NAL.0000001", "A272", "Organic Acid Inhibitor A272", 102, 102, "gal", new System.DateTime(2018,06,20), "2016-Midland ,TX", "S2","1243",1,"1234","ml");
        //    shipmentMaterials.Id = 0;
        //    mockShipments = new List<GoodsIssue>();
        //    mockShipment = new GoodsIssue(1, "SH1000000001", "Demobilization", "Well", "SLB", "CACTUS 129", "10000001", "Shipped");//("Pallets", "Test_test1", "1", "OilField");
        //    mockShipment.AddMaterial(shipmentMaterials);
        //    mockShipments.Add(mockShipment);
        //}
        ///// <summary>
        ///// Test Case: to Get HandlingUnits
        ///// </summary>
        //[TestMethod]
        //public void Should_GetShipments()
        //{
        //       //expect
        //        mockShipmentRepository.Expect(r => r.GetShipmentDetails(shipmentId)).IgnoreArguments().Return(mockShipments);
        //        //act
        //        var result = mockShipmentService.GetShipments(shipmentId);
        //        // assert
        //        Assert.IsNotNull(result);
        //        Assert.AreEqual(result.Count, 1);
          
           
        //}
    }
}
