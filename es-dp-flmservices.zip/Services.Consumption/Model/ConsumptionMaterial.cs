﻿using Services.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLM.Services.ConsumptionService.Model
{
    public class ConsumptionMaterial
    {
        public string Id { get; private set; }
        public string MaterialNumber { get; private set; }
        public string MaterialDesc { get; private set; }
        public string UOM { get; private set; }
        public string BatchNumber { get; private set; }
        public string SerialNumber { get; private set; }
        public string SplitValuation { get; private set; }
        public string Plant { get; private set; }
        public string IssuingStorageLocation { get; private set; }
        public string ReceivingStorageLocation { get; private set; }
        public string SpecialStockIndicator { get; private set; }
        public List<Consumption> Consumptions { get; private set; }
        public decimal ReceivedQuantity { get; private set; }

        public ConsumptionMaterial(string id,string materialNumber, string materialDesc, string uom,string batchNumber,string serialNumber,
            string splitValuation,string plant,string issuingStorageLocation,string receivingStorageLocation,string specialStockIndicator, List<Consumption> consumptions, decimal receivedQuantity)
        {
            Id = id;
            MaterialNumber = materialNumber;
            MaterialDesc = materialDesc;
            UOM = uom;
            BatchNumber = batchNumber;
            SerialNumber = serialNumber;
            SplitValuation = splitValuation;
            Plant = plant;
            IssuingStorageLocation = issuingStorageLocation;
            ReceivingStorageLocation = receivingStorageLocation;
            SpecialStockIndicator = specialStockIndicator;
            Consumptions = consumptions;
            ReceivedQuantity = receivedQuantity;

            if (string.IsNullOrWhiteSpace(Id))
            {
                AssiginId();
            }
        }
        public void AssiginId()
        {
            if (string.IsNullOrEmpty(Id))
                Id = Guid.NewGuid().ToString();
        }

        public void SetReceivedQuantity(decimal qty)
        {
            ReceivedQuantity = qty;
        }
        //
        public void AddConsumption(Consumption consumption)
        {
            if (Consumptions == null)
                Consumptions = new List<Consumption>();
            if (consumption == null)
            {
                Guard.ForNull(consumption, "consumption can not be null");
            }
            consumption?.AssiginId();

            Consumptions.Add(consumption);
        }
        public void RemoveConsumtion(Consumption consumption)
        {
            int matchingIndex = Consumptions.FindIndex(x => x.Id.Equals(consumption.Id));
            if (matchingIndex > 0)
                Consumptions.RemoveAt(matchingIndex);
        }
    }
}
