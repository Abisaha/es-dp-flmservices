﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FLM.Services.ApplicationCommon.Dto;

namespace FLM.Services.ShipmentService
{
    public interface IShipmentServiceClient
    {
        ConsumptionDataDto GetConsumptionData(string jobId);

    }
}
