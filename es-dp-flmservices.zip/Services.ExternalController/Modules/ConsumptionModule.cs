﻿using System;
using Autofac;
using FLM.Services.ConsumptionService;
using FLM.Services.ConsumptionService.Interface;
using FLM.Services.ConsumptionService.Persistence.Context;
using FLM.Services.ConsumptionService.Repository;
using Services.Common.Logger;

namespace FLM.Services.ExternalController.Modules
{
    /// <summary>
    /// Consumption service module from Autofac
    /// </summary>
    public class ConsumptionModule : Module
    {
        /// <summary>
        /// Error logging
        /// </summary>
        private readonly ILogger logger;

        /// <summary>
        /// Default constructor
        /// </summary>
        public ConsumptionModule()
        {
            logger = LoggerFactory.GetLogger();
        }

        /// <summary>
        /// To register User Service Components and Service.
        /// </summary>
        /// <param name="builder"></param>
        protected override void Load(ContainerBuilder builder)
        {
            try
            {
                builder.RegisterType<ConsumptionService.ConsumptionService>().As<IConsumptionService>().PropertiesAutowired();
                builder.RegisterType<ConsumptionRepository>().As<IConsumptionRepository>().PropertiesAutowired();
                builder.RegisterType<ConsumptionDBContext>().As<IConsumptionDBContext>();
                builder.RegisterType<ConsumptionServiceClient>().As<IConsumptionServiceClient>().PropertiesAutowired();
                base.Load(builder);
            }
            catch (Exception ex)
            {
                logger.LogException(this.GetType().ToString(), "Error encountered while registering Application Components and its service", LogLevel.ERROR, ex);
            }

        }
    }
}