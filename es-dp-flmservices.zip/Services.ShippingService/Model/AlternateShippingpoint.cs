﻿using Services.Common.Entity;


namespace FLM.Services.ShippingService.Model
{
    public class AlternateShippingpoint : ValueObject<AlternateShippingpoint>
    {
        public string LocationId { get; private set; }

        public string Name { get; private set; }
        public string Xid { get; private set; }


        internal AlternateShippingpoint()
        {

        }
        /// <summary>
        /// Constructor for Shipping Point
        /// </summary>
        /// <param name="locationId"></param>
        /// <param name="name"></param>
        /// <param name="xid"></param>

        public AlternateShippingpoint(string locationId, string name, string xid)
        {
            LocationId = locationId;
            Name = name;
            Xid = xid;
        }

    }
}
