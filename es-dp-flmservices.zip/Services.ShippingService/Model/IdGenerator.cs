﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Services.Common.Entity;

namespace FLM.Services.ShippingService.Model
{
    public class IdGenerator : AuditableEntity<int>
    {
        public string FormatText { get; private set; }
        public int SequenceNumber { get; private set; }
        [NotMapped]
        public int IncreamentBy { get; private set; }
        [NotMapped]
        public string ComputedValue
        {
            get
            {
                return FormatText + SequenceNumber.ToString().PadLeft(7, '0');
            }
            private set
            {
                value = FormatText + SequenceNumber.ToString().PadLeft(7, '0');
            }
        }
        protected IdGenerator()
        {

        }
        public IdGenerator(string formatText, int sequenceNumber)
        {
            this.FormatText = formatText;
            this.SequenceNumber = sequenceNumber;
        }
        public void SetIncreamentBy(int value)
        {
            IncreamentBy = value;
            this.SequenceNumber = this.SequenceNumber + value;
        }
        public void AssignValue(string formatText, int sequenceNumber, int increamentValue)
        {
            this.FormatText = formatText;
            this.SequenceNumber = sequenceNumber;
            IncreamentBy = increamentValue;
        }
    }
}
