﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FLM.Services.ShippingService.Model;
using Services.Common.Context;

namespace FLM.Services.ShippingService.Persistence.Mappings
{

    [ExcludeFromCodeCoverage]
    public class IdGeneratorMapping : IDomain2PersistenceModelMapper
    {
        /// <summary>
        ///  This method is called when the model for a derived context has been initialized,
        ///   but before the model has been locked down and used to initialize the context.
        ///   Overridden to configure before it is locked down.
        /// </summary>
        /// <param name="modelBuilder">builder that defines the model for the context being created</param>
        public void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<IdGenerator>()
                .MapToStoredProcedures();

        }
    }
}
