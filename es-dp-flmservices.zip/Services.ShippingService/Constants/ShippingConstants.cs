﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLM.Services.ShippingService.Constants
{
    public class ShippingConstants
    {
        public const string MobilizationRequestNumberPrefix = "MR";
        public const string DeMobilizationRequestNumberPrefix = "DR";
    }
}
