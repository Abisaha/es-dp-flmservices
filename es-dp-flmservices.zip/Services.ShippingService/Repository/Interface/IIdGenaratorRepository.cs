﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FLM.Services.ShippingService.Model;
using Services.Common.Repository;

namespace FLM.Services.ShippingService.Repository.Interface
{
    public interface IIdGenaratorRepository : IGenericRepository<IdGenerator>
    {
        void GenerateId(IdGenerator idGenerator);
    }
}
