﻿using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using FLM.Services.ShippingService.Model;
using FLM.Services.ShippingService.Persistence.Context;
using FLM.Services.ShippingService.Repository.Interface;
using Services.Common.Exceptions;
using Services.Common.Repository;

namespace FLM.Services.ShippingService.Repository
{
    [ExcludeFromCodeCoverage]
    public class IdGenaratorRepository : GenericRepository<IdGenerator>, IIdGenaratorRepository
    {
        #region Constructor
        public IdGenaratorRepository(IDBShippingContext context)
            : base(context)
        {

        }

        public void GenerateId(IdGenerator idGenerator)
        {
            try
            {
                var dbSet = ((ShippingContext)Context).IdGeneator;
                dbSet.Add(idGenerator);
            }
            catch (SqlException ex)
            {
                throw new RepositoryException(logger, "An error occurred during a database operation", ex, true);
            }
            catch (DataException ex)
            {
                throw new RepositoryException(logger, "An error occurred while querying data", ex, true);
            }
        }
        #endregion.
    }
}
