﻿using FDP.Queue.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLM.Queue.Model
{
    public class SAPMessage:FDPBaseMessage
    {
        public string message { get; set; }
    }
}
