﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace FLM.Queue.Model
{
    public class QueueAuditContext 
    {
       

        public string TimeZoneStandardName
        {
            get;set;
           
        }

        public string TransactionID
        {
            get;
            set;
            
        }

        public string UserAlias
        {
            get;
            set;
           
        }

        public void InitTransactionID()
        {
            throw new NotImplementedException();
        }

        public void SetPrincipal(string userAlias)
        {
            throw new NotImplementedException();
        }

        public void SetTimeZone(string timeZoneStandardName)
        {
            throw new NotImplementedException();
        }
    }
}
