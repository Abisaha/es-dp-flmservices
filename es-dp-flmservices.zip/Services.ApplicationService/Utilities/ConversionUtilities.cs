﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FLM.Services.ApplicationCommon.Enum;
using FLM.Services.ApplicationCommon.Constants;

namespace FLM.Services.CommonService.Utilities
{
    public class ConversionUtilities
    {
        public static MaterialsType MaterialTypeConverter(string typeName)
        {
            MaterialsType type;
            switch (typeName.Trim().ToLower())
            {
                case ApplicationConstants.Bulk:
                    type = MaterialsType.Bulk;
                    break;
                case ApplicationConstants.BulkDry:
                    type = MaterialsType.BulkDry;
                    break;
                case ApplicationConstants.BulkLiquid:
                    type = MaterialsType.BulkLiquid;
                    break;
                case ApplicationConstants.GeneralCargo:
                    type = MaterialsType.GeneralCargo;
                    break;
                case ApplicationConstants.RollingAsset:
                    type = MaterialsType.RollingAsset;
                    break;
                default:
                    type = MaterialsType.Others;
                    break;
            }
            return type;
        } 
    }
}
