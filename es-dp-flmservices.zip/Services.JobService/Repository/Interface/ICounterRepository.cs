﻿using FLM.Services.JobService.Model;
using Services.Common.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLM.Services.JobService.Repository.Interface
{
   public interface ICounterRepository : IGenericDocumentRepository<Counter>
    {
        Task<int> GetUniqueId(Dictionary<string, string> keyValues);
    }
}
