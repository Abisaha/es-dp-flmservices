﻿using FLM.Services.JobService.Model;
using Services.Common.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FLM.Services.JobService.Persistence.Context;
using Services.Common;
using FLM.Services.JobService.Repository.Interface;
using MongoDB.Bson;
using MongoDB.Driver;
using Services.Common.Exceptions;

namespace FLM.Services.JobService.Repository
{
  public  class CounterRepository : GenericDocumentRepository<Counter>, Interface.ICounterRepository
    {
        public CounterRepository(IJobDbContext jobDbContext, IAuditContext auditContext)
          : base("counters", jobDbContext, auditContext)
        {

        }
        public async Task<int> GetUniqueId(Dictionary<string, string> keyValues)
        {
            try
            {
                if (keyValues.Count == 0) throw new RepositoryException("Can not generate id with out filter condition");
                FilterDefinition<Counter> filter = null;
                foreach (string key in keyValues.Keys)
                {
                    string value = keyValues[key];
                    if (filter == null)
                    {
                        filter = Builders<Counter>.Filter.Eq(key, value);
                    }
                    else
                    {
                        filter = filter & Builders<Counter>.Filter.Eq(key, value);
                    }
                }

                UpdateDefinition<Counter> updateDef = Builders<Counter>.Update.Inc("seq", 1);
                var result = await this.FindOneAndUpdate(updateDef, filter, true, true);
                return result.Seq == 0? 1 : (result.Seq + 1);

            }
            catch (MongoException ex)
            {
                throw new RepositoryException(logger, "An error occurred while getting the unique id", ex, true);
            }
        } 
    }
}
