﻿using Services.Common.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLM.Services.JobService.Model
{
  public  class Counter : Entity<string>
    {
        public int? ProjectSeq { get; set; }

        public int? OperationSeq { get; set; }

        public int Seq { get; set; }
    }
}
