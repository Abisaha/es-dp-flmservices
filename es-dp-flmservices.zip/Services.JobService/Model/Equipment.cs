﻿using FLM.Services.ApplicationCommon.Model;
using Services.Common;
using Services.Common.Entity;
using System.Collections.Generic;

namespace FLM.Services.JobService.Model
{
    public class Equipment : Entity<string>
    {

        public string Code { get; private set; }
        public string Description { get; private set; }
        public string UOM { get; private set; }

        public string Sourcetype { get; private set; }

        public string Source { get; private set; }

        public string Storagelocation { get; private set; }

        public bool RollingAsset { get; private set; }
        public string Classification { get; private set; }

        public LocationInfo ShippingPoint { get; private set; }

        public string MaterialId { get; set; }        
        public MobilizationType MobilizationType { get; set; }
        
        public List<Attributes> WeightsDimension { get; set; }
        public Equipment(string id, string code,string description, string uom,string sourcetype,
                         string source,  string storagelocation, bool rollingAsset, string materialId,
                         MobilizationType mobilizationType, List<Attributes> weightsDimension, LocationInfo shippingPoint, string classification)
        {
            Id = !string.IsNullOrEmpty(id) ? id : null;
            Code = code;
            Description = description;
            UOM = uom;
            Sourcetype = sourcetype;
            Source = source;
            Storagelocation = storagelocation;
            RollingAsset = rollingAsset;
            MaterialId = materialId;
            MobilizationType = mobilizationType;
            WeightsDimension = weightsDimension;
            ShippingPoint = shippingPoint;
            Classification = classification;
        }       
        public void CreateEquimentId(string id)
        {
            Id = id;
        }

        public void UpdateClassification(string classification)
        {
            Classification = classification;
        }
        public void UpdateWeightsDimension(List<Attributes> attribute)
        {
            Guard.ForNull(attribute, "Weight and dimensions can not be null.");
            WeightsDimension = new List<Attributes>();
            foreach(var item in attribute)
            {
                Attributes attibute=new Attributes(item.Type, item.DataType, item.Range, item.Value, item.Uom);
                WeightsDimension.Add(attibute);
            }           
        }
    }
}
