﻿using Services.Common.Domain;
using FLM.Services.JobService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLM.Services.JobService.DomainEventHandlers
{
   public class GetUniqueIdEventHandler : IDomainEventHandler<GetUniqueIdEvent>
    {
        public readonly IJobService _jobService;
        public void Handle(GetUniqueIdEvent args)
        {
            var result = _jobService.GetUniqueId(args.KeyValues);
            args.Id = result.Id.ToString();

        }

        public GetUniqueIdEventHandler(IJobService jobService)
        {
            _jobService = jobService;
        }
    }
}
