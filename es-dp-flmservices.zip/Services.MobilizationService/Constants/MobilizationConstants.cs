﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLM.Services.MobilizationService.Constants
{
    public class MobilizationConstants
    {
        public const string MobilizationRequestNumberPrefix = "MR";
    }
}
