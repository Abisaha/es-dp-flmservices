﻿namespace FLM.Services.MobilizationService.Model
{
    public enum MobilizationType
    {
        Materials,
        Equipments
    }
}
